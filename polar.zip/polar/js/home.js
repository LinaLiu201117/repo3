$(document).ready(function() {
	$(".arrow").click(function(){
		$("body,html").animate({
			scrollTop:"630px"
			},500);
		
	});
});